'use client'
import { useState, useEffect }  from 'react'
import { useRouter }            from 'next/navigation'
import { createClient }         from '../lib/supabase/client'
import { getDayIndex, DAY_NAMES, GOAL_COLORS, DEFAULT_GOALS } from '../lib/supabase/utils'
import WeeklyPlanner            from './WeeklyPlanner'

/* ── Brand tokens ───────────────────────────────────────── */
const C = {
  bg:'#0A0E1A', surface:'#131826', surfaceHigh:'#192033',
  border:'#1E2840', borderBright:'#263352',
  accent:'#00C2FF',   accentSoft:'rgba(0,194,255,0.10)',  accentGlow:'rgba(0,194,255,0.22)',
  success:'#00E5A0',  successSoft:'rgba(0,229,160,0.10)',
  amber:'#F5B94E',    amberSoft:'rgba(245,185,78,0.10)',
  text:'#EDF0F7', textSub:'#6B7898', textMuted:'#2E3D5C',
  error:'#FF6B6B',
}

const ANIM = `
  @keyframes rippleOut { 0%{transform:scale(.4);opacity:.8} 100%{transform:scale(2.8);opacity:0} }
  @keyframes fadeUp    { from{opacity:0;transform:translateY(6px)} to{opacity:1;transform:translateY(0)} }
`
const fmtMins = m => m >= 60 ? `${Math.floor(m/60)}h${m%60>0?' '+(m%60)+'m':''}` : `${m}m`
const GoalDot = ({ color, size=7 }) =>
  <span style={{ display:'inline-block', width:size, height:size, borderRadius:'50%', background:color||'#333', flexShrink:0 }}/>

/* ── Onboarding overlay (first-time users with no goals) ── */
function Onboarding({ onSave, saving }) {
  const [goals, setGoals] = useState(DEFAULT_GOALS.map(g => ({ ...g })))
  const set = (i, val) => setGoals(prev => prev.map((g, idx) => idx===i ? {...g, label:val} : g))

  return (
    <div style={{ minHeight:'100vh', background:C.bg, display:'flex', alignItems:'center',
      justifyContent:'center', padding:24 }}>
      <div style={{ width:'100%', maxWidth:440, background:C.surface,
        border:`1px solid ${C.border}`, borderRadius:16, padding:'36px 32px' }}>
        <div style={{ display:'flex', alignItems:'center', gap:9, marginBottom:28 }}>
          <svg width="20" height="20" viewBox="0 0 22 22" fill="none">
            <path d="M4 3 L11 19 L18 3" stroke={C.accent} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M7.5 10 L14.5 10" stroke={C.accent} strokeWidth="1.2" strokeLinecap="round" opacity=".4"/>
          </svg>
          <span style={{ fontSize:14, fontWeight:800, letterSpacing:'.12em', color:C.text }}>CHANNEL</span>
        </div>

        <h1 style={{ fontSize:22, fontWeight:800, letterSpacing:'-.02em', color:C.text, marginBottom:8 }}>
          What are you trying to become?
        </h1>
        <p style={{ fontSize:13, color:C.textSub, lineHeight:1.6, marginBottom:28 }}>
          Name your three main goals. These anchor everything — every task you add will flow toward one of them.
        </p>

        <div style={{ display:'flex', flexDirection:'column', gap:12, marginBottom:28 }}>
          {goals.map((g, i) => (
            <div key={i} style={{ display:'flex', alignItems:'center', gap:10 }}>
              <span style={{ width:10, height:10, borderRadius:'50%', background:g.color, flexShrink:0 }}/>
              <input value={g.label} onChange={e => set(i, e.target.value)}
                placeholder={`Goal ${i+1}…`}
                style={{ flex:1, background:C.bg, border:`1px solid ${C.border}`, borderRadius:9,
                  padding:'11px 14px', color:C.text, fontSize:13, outline:'none', transition:'border-color .15s' }}
                onFocus={e=>e.target.style.borderColor=g.color}
                onBlur={e=>e.target.style.borderColor=C.border}
              />
            </div>
          ))}
        </div>

        <button onClick={() => onSave(goals)} disabled={saving || goals.some(g=>!g.label.trim())}
          style={{ width:'100%', background:C.accent, border:'none', borderRadius:10,
            padding:'13px', color:'#0A0E1A', fontSize:14, fontWeight:800,
            letterSpacing:'.04em', opacity:saving?0.7:1 }}>
          {saving ? 'Saving…' : 'Begin carving →'}
        </button>
      </div>
    </div>
  )
}

/* ── Sidebar ────────────────────────────────────────────── */
function Sidebar({ view, setView, goals, tasks, userEmail, onSignOut, onPlanWeek, aiEnabled }) {
  const done  = tasks.filter(t=>t.done).length
  const total = tasks.length
  const pct   = total > 0 ? done/total : 0
  const initial = (userEmail||'?')[0].toUpperCase()

  const nav = [
    { id:'today', icon:'◎', label:'Today'     },
    { id:'week',  icon:'▦', label:'This Week'  },
    { id:'goals', icon:'◈', label:'Goals'      },
  ]

  const handlePlanWeek = () => onPlanWeek()

  return (
    <div style={{ width:210, flexShrink:0, background:C.bg, borderRight:`1px solid ${C.border}`,
      display:'flex', flexDirection:'column', padding:'26px 0 20px' }}>

      <div style={{ padding:'0 20px 22px', borderBottom:`1px solid ${C.border}` }}>
        <div style={{ display:'flex', alignItems:'center', gap:9 }}>
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <path d="M4 3 L11 19 L18 3" stroke={C.accent} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M7.5 10 L14.5 10" stroke={C.accent} strokeWidth="1.2" strokeLinecap="round" opacity=".4"/>
          </svg>
          <span style={{ fontSize:15, fontWeight:800, letterSpacing:'.12em', color:C.text }}>CHANNEL</span>
        </div>
      </div>

      <nav style={{ padding:'16px 10px', flex:1 }}>
        {nav.map(n => {
          const active = view===n.id
          return (
            <button key={n.id} onClick={()=>setView(n.id)}
              style={{ width:'100%', display:'flex', alignItems:'center', gap:10,
                padding:'9px 12px', borderRadius:8, marginBottom:2, border:'none',
                background:active?C.accentSoft:'transparent',
                color:active?C.accent:C.textSub,
                fontSize:13, fontWeight:active?600:400, transition:'all .15s' }}>
              <span style={{ fontSize:13, opacity:.85 }}>{n.icon}</span>
              {n.label}
              {active && <span style={{ marginLeft:'auto', width:4, height:4, borderRadius:'50%', background:C.accent }}/>}
            </button>
          )
        })}
      </nav>

      {/* Plan my week button */}
      <div style={{ padding:'0 10px 14px' }}>
        <button onClick={onPlanWeek}
          style={{ width:'100%', background:C.accentSoft,
            border:`1px solid ${C.accentGlow}`, borderRadius:9,
            color:C.accent, fontSize:12, fontWeight:700,
            padding:'10px 12px', transition:'all .15s',
            display:'flex', alignItems:'center', justifyContent:'center', gap:7 }}
          onMouseEnter={e=>{ e.currentTarget.style.background=C.accent; e.currentTarget.style.color='#0A0E1A' }}
          onMouseLeave={e=>{ e.currentTarget.style.background=C.accentSoft; e.currentTarget.style.color=C.accent }}>
          <span style={{ fontSize:14 }}>✦</span>
          {aiEnabled ? 'Plan my week' : 'Add tasks'}
        </button>
      </div>

      {/* Channel depth meter */}
      <div style={{ padding:'16px 20px', borderTop:`1px solid ${C.border}` }}>
        <div style={{ fontSize:9, fontWeight:700, letterSpacing:'.1em', color:C.textMuted,
          marginBottom:12, textTransform:'uppercase' }}>Channel Depth</div>
        <div style={{ display:'flex', gap:10, alignItems:'flex-end' }}>
          <div style={{ width:6, height:80, background:C.surface, borderRadius:3, overflow:'hidden', position:'relative', flexShrink:0 }}>
            <div style={{ position:'absolute', bottom:0, left:0, right:0, height:`${pct*100}%`,
              background:`linear-gradient(to top, ${C.accent}, ${C.accentGlow})`,
              borderRadius:3, transition:'height .6s ease' }}/>
          </div>
          <div style={{ flex:1 }}>
            {goals.map(g => {
              const gT = tasks.filter(t=>t.goal_id===g.id)
              const gD = gT.filter(t=>t.done).length
              return (
                <div key={g.id} style={{ display:'flex', alignItems:'center', gap:6, marginBottom:7 }}>
                  <GoalDot color={g.color} size={5}/>
                  <span style={{ fontSize:10, color:C.textSub, flex:1,
                    whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{g.short||g.label}</span>
                  <span style={{ fontSize:10, color:C.textMuted }}>{gD}/{gT.length}</span>
                </div>
              )
            })}
          </div>
        </div>
        <div style={{ marginTop:10, fontSize:10, color:C.textMuted }}>
          {Math.round(pct*100)}% carved this week
        </div>
      </div>

      {/* User */}
      <div style={{ padding:'14px 10px 0' }}>
        <div style={{ display:'flex', alignItems:'center', gap:9, padding:'9px 12px',
          background:C.surface, borderRadius:9, marginBottom:14 }}>
          <div style={{ width:28, height:28, borderRadius:'50%', flexShrink:0,
            background:`linear-gradient(135deg, ${C.accent}, ${C.success})`,
            display:'flex', alignItems:'center', justifyContent:'center',
            fontSize:11, fontWeight:800, color:C.bg }}>{initial}</div>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ fontSize:11, color:C.textSub, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
              {userEmail}
            </div>
          </div>
          <button onClick={onSignOut} title="Sign out"
            style={{ background:'transparent', border:'none', color:C.textMuted, fontSize:14, padding:2 }}>
            ↩
          </button>
        </div>
        <div style={{ textAlign:'center', fontSize:10, color:C.textMuted, letterSpacing:'.06em', fontStyle:'italic' }}>
          The channel deepens.
        </div>
      </div>
    </div>
  )
}

/* ── TaskRow ────────────────────────────────────────────── */
function TaskRow({ task, goals, onToggle, rippling, expanded, onExpand, onDelete }) {
  const goal = goals.find(g=>g.id===task.goal_id)
  const subs = Array.isArray(task.subtasks) ? task.subtasks : []

  return (
    <div style={{ marginBottom:8, borderRadius:11, overflow:'hidden',
      border:`1px solid ${task.done?C.border:task.priority==='high'?C.accentGlow:C.border}`,
      background:task.done?'rgba(255,255,255,0.015)':C.surface,
      opacity:task.done?.45:1, transition:'opacity .3s, border-color .3s',
      animation:'fadeUp .25s ease' }}>

      <div style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 14px', cursor:'pointer' }}
        onClick={()=>subs.length>0&&onExpand(task.id)}>

        {/* Checkbox with ripple */}
        <div style={{ position:'relative', flexShrink:0 }}>
          {rippling && (
            <div style={{ position:'absolute', inset:-4, borderRadius:'50%',
              background:task.done?C.success:C.accentGlow,
              animation:'rippleOut .65s ease forwards', pointerEvents:'none' }}/>
          )}
          <div onClick={e=>{e.stopPropagation();onToggle(task.id,task.done)}}
            style={{ width:20, height:20, borderRadius:6, flexShrink:0, display:'flex',
              alignItems:'center', justifyContent:'center', transition:'all .2s',
              border:task.done?'none':`2px solid ${C.borderBright}`,
              background:task.done?C.success:'transparent',
              boxShadow:task.done?`0 0 8px ${C.successSoft}`:'none' }}>
            {task.done && (
              <svg width="11" height="9" viewBox="0 0 11 9" fill="none">
                <path d="M1 4L4 7.5L10 1" stroke={C.bg} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            )}
          </div>
        </div>

        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontSize:13.5, fontWeight:500,
            color:task.done?C.textMuted:C.text, textDecoration:task.done?'line-through':'none',
            whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis', transition:'color .2s' }}>
            {task.title}
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:7, marginTop:3 }}>
            {goal && <><GoalDot color={goal.color} size={5}/>
              <span style={{ fontSize:11, color:C.textSub }}>{goal.short||goal.label}</span>
              <span style={{ color:C.textMuted }}>·</span></>}
            <span style={{ fontSize:11, color:C.textSub }}>{fmtMins(task.mins)}</span>
          </div>
        </div>

        <div style={{ display:'flex', alignItems:'center', gap:7, flexShrink:0 }}>
          {task.priority==='high'&&!task.done&&(
            <span style={{ fontSize:9, fontWeight:700, letterSpacing:'.08em', textTransform:'uppercase',
              color:C.accent, background:C.accentSoft, padding:'2px 7px', borderRadius:4 }}>Priority</span>
          )}
          {subs.length>0&&(
            <span style={{ color:C.textMuted, fontSize:11, display:'inline-block',
              transform:expanded?'rotate(180deg)':'rotate(0deg)', transition:'transform .2s' }}>▾</span>
          )}
          <button onClick={e=>{e.stopPropagation();onDelete(task.id)}}
            style={{ background:'transparent', border:'none', color:C.textMuted,
              fontSize:14, opacity:0, transition:'opacity .15s', padding:'0 2px' }}
            onMouseOver={e=>e.currentTarget.style.opacity=1}
            onMouseOut={e=>e.currentTarget.style.opacity=0}>
            ×
          </button>
        </div>
      </div>

      {expanded && subs.length>0 && (
        <div style={{ padding:'0 14px 12px 46px', borderTop:`1px solid ${C.border}` }}>
          {subs.map((s,i) => (
            <div key={i} style={{ fontSize:12, color:C.textSub, padding:'5px 0',
              display:'flex', alignItems:'center', gap:8,
              borderBottom:i<subs.length-1?`1px solid ${C.border}`:'none' }}>
              <span style={{ width:3, height:3, borderRadius:'50%', background:C.textMuted, flexShrink:0 }}/>
              {typeof s==='string'?s:s.title}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

/* ── Add Task Modal ─────────────────────────────────────── */
function AddTaskRow({ goals, dayIndex, weekStart, onAdd, onCancel, aiAvailable }) {
  const [title, setTitle]     = useState('')
  const [goalId, setGoalId]   = useState(goals[0]?.id||'')
  const [mins, setMins]       = useState(30)
  const [priority, setPriority] = useState('normal')
  const [loading, setLoading] = useState(false)

  const handleAdd = async () => {
    if (!title.trim()) return
    setLoading(true)
    await onAdd({ title:title.trim(), goal_id:goalId||null, mins, priority, day_index:dayIndex, week_start:weekStart, subtasks:[] })
    setLoading(false)
  }

  return (
    <div style={{ background:C.surface, borderRadius:11, border:`1px solid ${C.accent}`,
      padding:'14px', marginBottom:8, boxShadow:`0 0 0 3px ${C.accentSoft}` }}>
      <input autoFocus value={title} onChange={e=>setTitle(e.target.value)}
        onKeyDown={e=>{ if(e.key==='Enter')handleAdd(); if(e.key==='Escape')onCancel() }}
        placeholder="Name this task…"
        style={{ width:'100%', background:'transparent', border:'none', outline:'none',
          color:C.text, fontSize:13, marginBottom:12 }}/>

      <div style={{ display:'flex', gap:8, flexWrap:'wrap', alignItems:'center' }}>
        {/* Goal picker */}
        <select value={goalId} onChange={e=>setGoalId(e.target.value)}
          style={{ background:C.bg, border:`1px solid ${C.border}`, borderRadius:7,
            color:C.textSub, fontSize:12, padding:'5px 8px', outline:'none' }}>
          <option value="">No goal</option>
          {goals.map(g=><option key={g.id} value={g.id}>{g.label}</option>)}
        </select>

        {/* Time */}
        <select value={mins} onChange={e=>setMins(Number(e.target.value))}
          style={{ background:C.bg, border:`1px solid ${C.border}`, borderRadius:7,
            color:C.textSub, fontSize:12, padding:'5px 8px', outline:'none' }}>
          {[15,30,45,60,90,120].map(m=><option key={m} value={m}>{fmtMins(m)}</option>)}
        </select>

        {/* Priority toggle */}
        <button onClick={()=>setPriority(p=>p==='high'?'normal':'high')}
          style={{ background:priority==='high'?C.accentSoft:'transparent',
            border:`1px solid ${priority==='high'?C.accent:C.border}`,
            borderRadius:7, color:priority==='high'?C.accent:C.textMuted,
            fontSize:11, fontWeight:priority==='high'?700:400, padding:'5px 10px' }}>
          {priority==='high'?'★ Priority':'☆ Priority'}
        </button>

        <div style={{ marginLeft:'auto', display:'flex', gap:8 }}>
          <button onClick={onCancel}
            style={{ background:'transparent', border:`1px solid ${C.border}`,
              borderRadius:7, color:C.textMuted, fontSize:12, padding:'5px 12px' }}>
            Cancel
          </button>
          <button onClick={handleAdd} disabled={loading||!title.trim()}
            style={{ background:C.accent, border:'none', borderRadius:7,
              color:'#0A0E1A', fontSize:12, fontWeight:800, padding:'5px 14px',
              opacity:loading||!title.trim()?0.6:1 }}>
            {loading?'…':'Carve'}
          </button>
        </div>
      </div>
    </div>
  )
}

/* ── Today View ─────────────────────────────────────────── */
function TodayView({ tasks, goals, onToggle, onAdd, onDelete, ripplingId, expandedId, setExpandedId, weekStart }) {
  const [showAdd, setShowAdd] = useState(false)
  const todayIdx = getDayIndex()
  const todayTasks = tasks.filter(t=>t.day_index===todayIdx)
  const pending = todayTasks.filter(t=>!t.done)
  const done    = todayTasks.filter(t=>t.done)
  const remainMins = pending.reduce((a,b)=>a+b.mins,0)

  const now = new Date()
  const dayName   = DAY_NAMES[todayIdx]||'Today'
  const monthNames = ['January','February','March','April','May','June','July','August','September','October','November','December']
  const dateStr = `${dayName}, ${monthNames[now.getMonth()]} ${now.getDate()}`

  return (
    <div style={{ flex:1, padding:'28px 32px', overflowY:'auto' }}>
      <div style={{ marginBottom:28 }}>
        <div style={{ fontSize:10, color:C.textMuted, letterSpacing:'.08em', textTransform:'uppercase', marginBottom:7 }}>{dateStr}</div>
        <h1 style={{ fontSize:26, fontWeight:800, letterSpacing:'-.025em', color:C.text, marginBottom:6 }}>Today's Focus</h1>
        <p style={{ fontSize:13, color:C.textSub }}>
          {todayTasks.length===0
            ? 'No tasks carved for today yet.'
            : pending.length===0
            ? 'All channels carved for today.'
            : `${pending.length} task${pending.length>1?'s':''} remaining — ${fmtMins(remainMins)} of work ahead.`}
        </p>
      </div>

      {pending.map(t=>(
        <TaskRow key={t.id} task={t} goals={goals} onToggle={onToggle} onDelete={onDelete}
          rippling={ripplingId===t.id} expanded={expandedId===t.id}
          onExpand={id=>setExpandedId(expandedId===id?null:id)}/>
      ))}

      {showAdd
        ? <AddTaskRow goals={goals} dayIndex={todayIdx} weekStart={weekStart}
            onAdd={async(data)=>{await onAdd(data);setShowAdd(false)}} onCancel={()=>setShowAdd(false)}/>
        : (
          <button onClick={()=>setShowAdd(true)}
            style={{ width:'100%', background:'transparent', border:`1px dashed ${C.border}`,
              borderRadius:11, color:C.textMuted, fontSize:13, padding:'11px 14px',
              textAlign:'left', marginBottom:24, transition:'border-color .15s' }}
            onMouseEnter={e=>e.currentTarget.style.borderColor=C.accentGlow}
            onMouseLeave={e=>e.currentTarget.style.borderColor=C.border}>
            + Add a task for today
          </button>
        )
      }

      {done.length>0&&(
        <div style={{ marginTop:8 }}>
          <div style={{ fontSize:9, fontWeight:700, letterSpacing:'.1em', color:C.textMuted,
            textTransform:'uppercase', marginBottom:10 }}>Completed · {done.length}</div>
          {done.map(t=>(
            <TaskRow key={t.id} task={t} goals={goals} onToggle={onToggle} onDelete={onDelete}
              rippling={ripplingId===t.id} expanded={expandedId===t.id}
              onExpand={id=>setExpandedId(expandedId===id?null:id)}/>
          ))}
        </div>
      )}
    </div>
  )
}

/* ── Week View ──────────────────────────────────────────── */
function WeekView({ tasks, goals, onAdd, onDelete, onToggle, ripplingId, expandedId, setExpandedId, weekStart }) {
  const [addingDay, setAddingDay] = useState(null)

  return (
    <div style={{ flex:1, padding:'28px 24px', overflowY:'auto' }}>
      <div style={{ marginBottom:24 }}>
        <div style={{ fontSize:10, color:C.textMuted, letterSpacing:'.08em', textTransform:'uppercase', marginBottom:7 }}>
          Week of {new Date(weekStart+'T12:00:00').toLocaleDateString('en-GB',{day:'numeric',month:'long'})}
        </div>
        <h1 style={{ fontSize:26, fontWeight:800, letterSpacing:'-.025em', color:C.text }}>This Week's Channel</h1>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:10, marginBottom:20 }}>
        {DAY_NAMES.slice(0,5).map((day, i) => {
          const todayIdx = getDayIndex()
          const isToday  = i===todayIdx
          const dayTasks = tasks.filter(t=>t.day_index===i)
          return (
            <div key={day} style={{ background:isToday?C.accentSoft:C.surface,
              border:`1px solid ${isToday?C.accentGlow:C.border}`, borderRadius:12, padding:'14px 12px',
              display:'flex', flexDirection:'column', minHeight:160 }}>
              <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:12 }}>
                <span style={{ fontSize:10, fontWeight:700, letterSpacing:'.06em', color:isToday?C.accent:C.textSub }}>
                  {day.slice(0,3).toUpperCase()}
                </span>
                {isToday&&<span style={{ fontSize:9, fontWeight:700, color:C.accent,
                  background:C.accentSoft, padding:'1px 6px', borderRadius:3 }}>TODAY</span>}
              </div>

              <div style={{ flex:1 }}>
                {dayTasks.map(t=>(
                  <div key={t.id} style={{ fontSize:11, color:t.done?C.textMuted:C.textSub,
                    padding:'4px 0', textDecoration:t.done?'line-through':'none',
                    borderBottom:`1px solid ${C.border}`, display:'flex', alignItems:'flex-start', gap:5,
                    cursor:'pointer' }} onClick={()=>onToggle(t.id,t.done)}>
                    <GoalDot color={goals.find(g=>g.id===t.goal_id)?.color} size={5}/>
                    <span style={{ lineHeight:1.3, flex:1 }}>{t.title}</span>
                    <button onClick={e=>{e.stopPropagation();onDelete(t.id)}}
                      style={{ background:'transparent', border:'none', color:C.textMuted,
                        fontSize:12, opacity:0, transition:'opacity .1s', flexShrink:0 }}
                      onMouseOver={e=>e.currentTarget.style.opacity=1}
                      onMouseOut={e=>e.currentTarget.style.opacity=0}>×</button>
                  </div>
                ))}
              </div>

              {addingDay===i
                ? <AddTaskRow goals={goals} dayIndex={i} weekStart={weekStart}
                    onAdd={async(data)=>{await onAdd(data);setAddingDay(null)}}
                    onCancel={()=>setAddingDay(null)}/>
                : (
                  <button onClick={()=>setAddingDay(i)}
                    style={{ marginTop:8, width:'100%', background:'transparent',
                      border:`1px dashed ${C.border}`, borderRadius:7, color:C.textMuted,
                      fontSize:11, padding:'6px', transition:'border-color .15s' }}
                    onMouseEnter={e=>e.currentTarget.style.borderColor=C.accentGlow}
                    onMouseLeave={e=>e.currentTarget.style.borderColor=C.border}>
                    + Add
                  </button>
                )
              }
            </div>
          )
        })}
      </div>
    </div>
  )
}

/* ── Goals View ─────────────────────────────────────────── */
function GoalsView({ goals, tasks }) {
  return (
    <div style={{ flex:1, padding:'28px 32px', overflowY:'auto' }}>
      <div style={{ marginBottom:28 }}>
        <div style={{ fontSize:10, color:C.textMuted, letterSpacing:'.08em', textTransform:'uppercase', marginBottom:7 }}>
          What you are becoming
        </div>
        <h1 style={{ fontSize:26, fontWeight:800, letterSpacing:'-.025em', color:C.text }}>Goals</h1>
      </div>

      {goals.length===0&&(
        <p style={{ fontSize:13, color:C.textSub }}>No goals set yet.</p>
      )}

      {goals.map(g=>{
        const gTasks = tasks.filter(t=>t.goal_id===g.id)
        const gDone  = gTasks.filter(t=>t.done).length
        const pct    = gTasks.length>0?Math.round((gDone/gTasks.length)*100):0
        return (
          <div key={g.id} style={{ background:C.surface, borderRadius:14,
            border:`1px solid ${C.border}`, padding:'20px', marginBottom:14,
            borderLeft:`3px solid ${g.color}` }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:14 }}>
              <h3 style={{ fontSize:15, fontWeight:700, color:C.text }}>{g.label}</h3>
              <div style={{ textAlign:'right' }}>
                <div style={{ fontSize:28, fontWeight:800, color:g.color, letterSpacing:'-.02em' }}>{pct}%</div>
                <div style={{ fontSize:10, color:C.textMuted }}>this week</div>
              </div>
            </div>
            <div style={{ height:5, background:C.bg, borderRadius:3, overflow:'hidden', marginBottom:14 }}>
              <div style={{ height:'100%', width:`${pct}%`, borderRadius:3, transition:'width .8s ease',
                background:`linear-gradient(90deg, ${g.color}99, ${g.color})` }}/>
            </div>
            <div style={{ fontSize:12, color:C.textSub }}>
              {gDone} of {gTasks.length} tasks completed this week
            </div>
          </div>
        )
      })}
    </div>
  )
}

/* ── Right Panel ────────────────────────────────────────── */
function RightPanel({ tasks, goals }) {
  const todayIdx = getDayIndex()
  const done  = tasks.filter(t=>t.done).length
  const total = tasks.length
  const pct   = total>0?Math.round((done/total)*100):0
  const todayTasks  = tasks.filter(t=>t.day_index===todayIdx)
  const todayDone   = todayTasks.filter(t=>t.done).length
  const remainMins  = todayTasks.filter(t=>!t.done).reduce((a,b)=>a+b.mins,0)

  const bars = DAY_NAMES.slice(0,5).map((d,i)=>{
    const dt = tasks.filter(t=>t.day_index===i)
    return { day:d.slice(0,3), total:dt.length, done:dt.filter(t=>t.done).length, today:i===todayIdx }
  })

  return (
    <div style={{ width:220, flexShrink:0, background:C.bg, borderLeft:`1px solid ${C.border}`,
      padding:'26px 16px', overflowY:'auto' }}>

      <div style={{ marginBottom:22 }}>
        <div style={{ fontSize:9, fontWeight:700, letterSpacing:'.1em', color:C.textMuted,
          textTransform:'uppercase', marginBottom:12 }}>Week Shape</div>
        <div style={{ display:'flex', gap:6 }}>
          {bars.map(d=>{
            const barPct = d.total>0?d.done/d.total:0
            return (
              <div key={d.day} style={{ flex:1 }}>
                <div style={{ height:52, borderRadius:7, overflow:'hidden', position:'relative',
                  background:C.surface, border:`1px solid ${d.today?C.accentGlow:C.border}`,
                  boxShadow:d.today?`0 0 10px ${C.accentSoft}`:'none' }}>
                  <div style={{ position:'absolute', bottom:0, left:0, right:0,
                    height:`${barPct*100}%`, transition:'height .5s ease',
                    background:d.today?`linear-gradient(to top,${C.accent},${C.accentGlow})`:barPct===1?C.success:'rgba(0,194,255,0.25)' }}/>
                </div>
                <div style={{ textAlign:'center', marginTop:5, fontSize:9, fontWeight:d.today?700:400,
                  letterSpacing:'.05em', textTransform:'uppercase', color:d.today?C.accent:C.textMuted }}>
                  {d.day}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      <div style={{ background:C.surface, borderRadius:10, padding:'13px',
        border:`1px solid ${C.border}`, marginBottom:20 }}>
        <div style={{ display:'flex', justifyContent:'space-between', marginBottom:8 }}>
          <span style={{ fontSize:11, color:C.textSub }}>Today</span>
          <span style={{ fontSize:13, fontWeight:700, color:C.accent }}>{todayDone}/{todayTasks.length}</span>
        </div>
        <div style={{ height:3, background:C.bg, borderRadius:2, overflow:'hidden', marginBottom:8 }}>
          <div style={{ height:'100%', borderRadius:2, transition:'width .5s',
            width:`${todayTasks.length>0?Math.round((todayDone/todayTasks.length)*100):0}%`,
            background:`linear-gradient(90deg,${C.accent}99,${C.accent})` }}/>
        </div>
        <div style={{ fontSize:10, color:C.textMuted }}>
          {remainMins>0?`${fmtMins(remainMins)} of work remaining`:'All done — channel carved.'}
        </div>
      </div>

      <div style={{ marginBottom:20 }}>
        <div style={{ fontSize:9, fontWeight:700, letterSpacing:'.1em', color:C.textMuted,
          textTransform:'uppercase', marginBottom:12 }}>Goal Channels</div>
        {goals.map(g=>{
          const gT = tasks.filter(t=>t.goal_id===g.id)
          const gD = gT.filter(t=>t.done).length
          const p  = gT.length>0?Math.round((gD/gT.length)*100):0
          return (
            <div key={g.id} style={{ marginBottom:13 }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:5, alignItems:'center' }}>
                <span style={{ fontSize:11, color:C.textSub, display:'flex', alignItems:'center', gap:6 }}>
                  <GoalDot color={g.color} size={5}/>{g.short||g.label.slice(0,12)}
                </span>
                <span style={{ fontSize:10, color:C.textMuted }}>{gD}/{gT.length}</span>
              </div>
              <div style={{ height:3, background:C.surface, borderRadius:2, overflow:'hidden' }}>
                <div style={{ height:'100%', width:`${p}%`, background:g.color, borderRadius:2, transition:'width .5s' }}/>
              </div>
            </div>
          )
        })}
      </div>

      <div style={{ padding:'13px', borderRadius:10, background:C.successSoft, border:`1px solid rgba(0,229,160,0.2)` }}>
        <div style={{ fontSize:9, fontWeight:700, letterSpacing:'.08em', color:C.success,
          marginBottom:7, textTransform:'uppercase' }}>Channel</div>
        <p style={{ fontSize:11, color:C.textSub, lineHeight:1.65 }}>
          {pct>=80
            ? 'The channel is carved deep this week. Keep the pace.'
            : pct>=50
            ? 'Good momentum. The channel is forming.'
            : 'The channel is waiting. Start with your top priority.'}
        </p>
      </div>
    </div>
  )
}

/* ── Root Dashboard ─────────────────────────────────────── */
export default function Dashboard({ user, initialGoals, initialTasks, weekStart }) {
  const router    = useRouter()
  const supabase  = createClient()
  const aiEnabled = !!process.env.NEXT_PUBLIC_AI_ENABLED // set in Vercel if ANTHROPIC_API_KEY exists

  const [goals,        setGoals]        = useState(initialGoals)
  const [tasks,        setTasks]        = useState(initialTasks)
  const [view,         setView]         = useState('today')
  const [expandedId,   setExpandedId]   = useState(null)
  const [ripplingId,   setRipplingId]   = useState(null)
  const [savingGoals,  setSavingGoals]  = useState(false)
  const [showPlanner,  setShowPlanner]  = useState(false)
  const [toast,        setToast]        = useState(null)  // { message, type }

  const showToast = (message, type='info') => {
    setToast({ message, type })
    setTimeout(() => setToast(null), 4000)
  }

  // Run carry-forward on mount (silently move stale tasks to today)
  useEffect(() => {
    fetch('/api/carry-forward', { method: 'POST' })
      .then(r => r.json())
      .then(({ carried, broken }) => {
        if (carried + broken > 0) {
          const msg = broken > 0
            ? `${broken} task${broken>1?'s':''} broken into smaller steps and moved to today.`
            : `${carried} task${carried>1?'s':''} carried forward to today.`
          showToast(msg, 'info')
          // Refresh tasks from server to get updated day_index
          router.refresh()
        }
      })
      .catch(() => {}) // silent fail — non-critical
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  /* First-time onboarding */
  if (goals.length === 0) {
    return (
      <>
        <style>{ANIM}</style>
        <Onboarding saving={savingGoals} onSave={async (draftGoals) => {
          setSavingGoals(true)
          const toInsert = draftGoals.filter(g=>g.label.trim()).map((g,i)=>({
            user_id:user.id, label:g.label.trim(),
            short:g.label.trim().split(' ').slice(0,2).join(' '),
            color:GOAL_COLORS[i]||g.color, position:i,
          }))
          const { data } = await supabase.from('goals').insert(toInsert).select()
          if (data) { setGoals(data); setSavingGoals(false) }
          else setSavingGoals(false)
        }}/>
      </>
    )
  }

  /* ── Mutations ── */
  const addTask = async (data) => {
    const { data: created } = await supabase
      .from('tasks').insert([{ ...data, user_id:user.id }]).select().single()
    if (created) setTasks(prev=>[...prev, created])
  }

  const toggleTask = async (id, currentDone) => {
    setRipplingId(id)
    setTimeout(()=>setRipplingId(null), 700)
    setTasks(prev=>prev.map(t=>t.id===id?{...t,done:!currentDone}:t))
    await supabase.from('tasks').update({ done:!currentDone }).eq('id',id)
  }

  const deleteTask = async (id) => {
    setTasks(prev=>prev.filter(t=>t.id!==id))
    await supabase.from('tasks').delete().eq('id',id)
  }

  const signOut = async () => {
    await supabase.auth.signOut()
    router.push('/login')
    router.refresh()
  }

  // Save AI-generated plan: bulk insert all tasks then refresh
  const savePlan = async (plannedTasks) => {
    if (!plannedTasks.length) { setShowPlanner(false); return }
    const toInsert = plannedTasks.map(t => ({ ...t, user_id: user.id }))
    const { data, error } = await supabase.from('tasks').insert(toInsert).select()
    if (!error && data) {
      setTasks(prev => [...prev, ...data])
      showToast(`${data.length} tasks carved into your week.`, 'success')
    }
    setShowPlanner(false)
  }

  const sharedProps = { tasks, goals, onAdd:addTask, onDelete:deleteTask,
    onToggle:toggleTask, ripplingId, expandedId, setExpandedId, weekStart }

  return (
    <>
      <style>{ANIM + `
        @keyframes toastIn { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }
      `}</style>

      <div style={{ fontFamily:"'Inter',-apple-system,sans-serif", background:C.bg,
        color:C.text, height:'100vh', display:'flex', overflow:'hidden', fontSize:14 }}>

        <Sidebar view={view} setView={setView} goals={goals} tasks={tasks}
          userEmail={user.email} onSignOut={signOut}
          onPlanWeek={() => setShowPlanner(true)} aiEnabled={aiEnabled}/>

        {view==='today' && <TodayView  {...sharedProps}/>}
        {view==='week'  && <WeekView   {...sharedProps}/>}
        {view==='goals' && <GoalsView  tasks={tasks} goals={goals}/>}

        {(view==='today'||view==='week') && <RightPanel tasks={tasks} goals={goals}/>}
      </div>

      {/* Weekly Planner modal */}
      {showPlanner && (
        <WeeklyPlanner
          goals={goals}
          weekStart={weekStart}
          aiEnabled={aiEnabled}
          onSave={savePlan}
          onClose={() => setShowPlanner(false)}
        />
      )}

      {/* Toast notification */}
      {toast && (
        <div style={{
          position:'fixed', bottom:24, left:'50%', transform:'translateX(-50%)',
          background: toast.type==='success' ? C.successSoft : C.accentSoft,
          border:`1px solid ${toast.type==='success' ? 'rgba(0,229,160,.3)' : C.accentGlow}`,
          color: toast.type==='success' ? C.success : C.accent,
          borderRadius:10, padding:'12px 20px', fontSize:13, fontWeight:500,
          zIndex:200, whiteSpace:'nowrap', backdropFilter:'blur(8px)',
          animation:'toastIn .25s ease', boxShadow:'0 8px 32px rgba(0,0,0,.4)',
        }}>
          {toast.message}
        </div>
      )}
    </>
  )
}
