'use client'
import { useState } from 'react'
import { DAY_NAMES } from '../lib/supabase/utils'

const C = {
  bg:'#0A0E1A', surface:'#131826', surfaceHigh:'#192033',
  border:'#1E2840', borderBright:'#263352',
  accent:'#00C2FF', accentSoft:'rgba(0,194,255,0.10)', accentGlow:'rgba(0,194,255,0.22)',
  success:'#00E5A0', successSoft:'rgba(0,229,160,0.10)',
  amber:'#F5B94E',
  text:'#EDF0F7', textSub:'#6B7898', textMuted:'#2E3D5C',
  error:'#FF6B6B', errorSoft:'rgba(255,107,107,0.10)',
}

const fmtMins = m => m >= 60 ? `${Math.floor(m/60)}h${m%60>0?' '+(m%60)+'m':''}` : `${m}m`

const GoalDot = ({ color, size=7 }) =>
  <span style={{ display:'inline-block', width:size, height:size,
    borderRadius:'50%', background:color||'#444', flexShrink:0 }}/>

/* ── Preview task card ───────────────────────────────────── */
function PreviewTask({ task, goals, onRemove }) {
  const goal = goals.find(g => g.id === task.goal_id)
  return (
    <div style={{ background:C.surface, border:`1px solid ${task.priority==='high'?C.accentGlow:C.border}`,
      borderRadius:10, padding:'11px 13px', marginBottom:7, display:'flex', alignItems:'flex-start', gap:10,
      animation:'fadeUp .2s ease' }}>
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontSize:13, fontWeight:500, color:C.text, marginBottom:4 }}>{task.title}</div>
        <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
          {goal && (
            <span style={{ display:'flex', alignItems:'center', gap:5, fontSize:11, color:C.textSub }}>
              <GoalDot color={goal.color} size={5}/>{goal.short||goal.label}
            </span>
          )}
          <span style={{ fontSize:11, color:C.textMuted }}>{DAY_NAMES[task.day_index]?.slice(0,3)||'?'}</span>
          <span style={{ fontSize:11, color:C.textMuted }}>{fmtMins(task.mins)}</span>
          {task.priority==='high' && (
            <span style={{ fontSize:9, fontWeight:700, letterSpacing:'.08em',
              color:C.accent, background:C.accentSoft, padding:'1px 6px', borderRadius:3,
              textTransform:'uppercase' }}>Priority</span>
          )}
        </div>
        {task.subtasks?.length > 0 && (
          <div style={{ marginTop:6, paddingLeft:8, borderLeft:`2px solid ${C.border}` }}>
            {task.subtasks.map((s,i) => (
              <div key={i} style={{ fontSize:11, color:C.textMuted, padding:'2px 0' }}>
                · {typeof s==='string'?s:s.title}
              </div>
            ))}
          </div>
        )}
      </div>
      <button onClick={()=>onRemove(task)}
        style={{ background:'transparent', border:'none', color:C.textMuted,
          fontSize:16, lineHeight:1, flexShrink:0, padding:'0 2px',
          transition:'color .15s' }}
        onMouseOver={e=>e.currentTarget.style.color=C.error}
        onMouseOut={e=>e.currentTarget.style.color=C.textMuted}>×</button>
    </div>
  )
}

/* ── Main Component ─────────────────────────────────────── */
export default function WeeklyPlanner({ goals, weekStart, onSave, onClose, aiEnabled }) {
  const [step,       setStep]       = useState('input')   // 'input' | 'preview' | 'saving'
  const [rawInput,   setRawInput]   = useState('')
  const [planned,    setPlanned]    = useState([])
  const [loading,    setLoading]    = useState(false)
  const [error,      setError]      = useState('')

  const dayGroups = DAY_NAMES.slice(0,5).reduce((acc, day, i) => {
    acc[i] = planned.filter(t => t.day_index === i)
    return acc
  }, {})

  const generate = async () => {
    if (!rawInput.trim()) return
    setLoading(true)
    setError('')
    try {
      const res  = await fetch('/api/ai/plan', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ rawInput, goals }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Generation failed')
      setPlanned(data.tasks)
      setStep('preview')
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const removeTask = (task) => setPlanned(prev => prev.filter(t => t !== task))

  const save = async () => {
    setStep('saving')
    await onSave(planned)
  }

  return (
    <>
      <style>{`
        @keyframes fadeUp { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
        @keyframes overlayIn { from{opacity:0} to{opacity:1} }
      `}</style>

      {/* Backdrop */}
      <div style={{ position:'fixed', inset:0, background:'rgba(10,14,26,0.92)',
        backdropFilter:'blur(6px)', zIndex:100, display:'flex', alignItems:'center',
        justifyContent:'center', padding:24, animation:'overlayIn .2s ease' }}
        onClick={e=>{ if(e.target===e.currentTarget) onClose() }}>

        <div style={{ width:'100%', maxWidth: step==='preview' ? 700 : 520,
          background:C.surface, border:`1px solid ${C.border}`,
          borderRadius:18, padding:'36px 32px', maxHeight:'90vh',
          overflowY:'auto', animation:'fadeUp .25s ease' }}>

          {/* Header */}
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:28 }}>
            <div>
              <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:10 }}>
                <svg width="18" height="18" viewBox="0 0 22 22" fill="none">
                  <path d="M4 3 L11 19 L18 3" stroke={C.accent} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M7.5 10 L14.5 10" stroke={C.accent} strokeWidth="1.2" strokeLinecap="round" opacity=".4"/>
                </svg>
                <span style={{ fontSize:11, fontWeight:700, letterSpacing:'.1em', color:C.textMuted, textTransform:'uppercase' }}>
                  {step==='input' ? 'Week Planning' : 'Your Week — Review & Save'}
                </span>
              </div>
              <h2 style={{ fontSize:22, fontWeight:800, letterSpacing:'-.02em', color:C.text }}>
                {step==='input' ? 'What needs to get done this week?' : `${planned.length} tasks carved for your week`}
              </h2>
              {step==='input' && (
                <p style={{ fontSize:13, color:C.textSub, marginTop:6, lineHeight:1.6 }}>
                  {aiEnabled
                    ? 'Write everything out — messy is fine. Channel will structure it into a plan.'
                    : 'Add tasks manually. Upgrade to use AI planning.'}
                </p>
              )}
              {step==='preview' && (
                <p style={{ fontSize:13, color:C.textSub, marginTop:6 }}>
                  Remove anything that shouldn't be there. Then save to your week.
                </p>
              )}
            </div>
            <button onClick={onClose}
              style={{ background:'transparent', border:'none', color:C.textMuted,
                fontSize:22, lineHeight:1, padding:'0 4px', flexShrink:0 }}>×</button>
          </div>

          {/* ── INPUT STEP ── */}
          {step === 'input' && (
            <>
              {/* Goals reminder */}
              <div style={{ marginBottom:20, padding:'14px', background:C.bg,
                borderRadius:10, border:`1px solid ${C.border}` }}>
                <div style={{ fontSize:9, fontWeight:700, letterSpacing:'.1em', color:C.textMuted,
                  textTransform:'uppercase', marginBottom:10 }}>Your goals</div>
                {goals.map(g => (
                  <div key={g.id} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:7 }}>
                    <GoalDot color={g.color} size={7}/>
                    <span style={{ fontSize:12, color:C.textSub }}>{g.label}</span>
                  </div>
                ))}
              </div>

              {/* Textarea */}
              {aiEnabled ? (
                <textarea value={rawInput} onChange={e=>setRawInput(e.target.value)}
                  placeholder={`Draft proposal for the client\nCall accountant about VAT\nWrite 500 words of chapter 3\nRun three times this week\nResearch competitor pricing\n…`}
                  rows={10}
                  style={{ width:'100%', background:C.bg, border:`1px solid ${C.border}`,
                    borderRadius:10, padding:'14px', color:C.text, fontSize:13,
                    lineHeight:1.7, outline:'none', resize:'vertical',
                    transition:'border-color .15s', fontFamily:'inherit' }}
                  onFocus={e=>e.target.style.borderColor=C.accent}
                  onBlur={e=>e.target.style.borderColor=C.border}
                />
              ) : (
                <div style={{ padding:'20px', background:C.bg, border:`1px dashed ${C.border}`,
                  borderRadius:10, textAlign:'center', marginBottom:16 }}>
                  <div style={{ fontSize:24, marginBottom:10 }}>✦</div>
                  <p style={{ fontSize:13, color:C.textSub, lineHeight:1.6 }}>
                    AI planning needs an Anthropic API key.<br/>
                    Add <code style={{ fontSize:11, background:C.surface, padding:'1px 6px',
                      borderRadius:4, color:C.accent }}>ANTHROPIC_API_KEY</code> to your Vercel environment variables.
                  </p>
                </div>
              )}

              {error && (
                <div style={{ marginTop:14, padding:'10px 14px', background:C.errorSoft,
                  border:`1px solid ${C.error}40`, borderRadius:8, fontSize:13, color:C.error }}>
                  {error}
                </div>
              )}

              <div style={{ display:'flex', gap:10, marginTop:20 }}>
                <button onClick={onClose}
                  style={{ flex:1, background:'transparent', border:`1px solid ${C.border}`,
                    borderRadius:10, color:C.textSub, fontSize:13, padding:'12px' }}>
                  Cancel
                </button>
                {aiEnabled && (
                  <button onClick={generate} disabled={loading || !rawInput.trim()}
                    style={{ flex:2, background:loading?C.accentSoft:C.accent,
                      border:`1px solid ${loading?C.accentGlow:C.accent}`,
                      borderRadius:10, color:loading?C.accent:'#0A0E1A',
                      fontSize:13, fontWeight:800, padding:'12px',
                      opacity:!rawInput.trim()?0.5:1, transition:'all .2s' }}>
                    {loading ? (
                      <span style={{ display:'flex', alignItems:'center', justifyContent:'center', gap:8 }}>
                        <span style={{ display:'inline-block', width:12, height:12, borderRadius:'50%',
                          border:`2px solid ${C.accent}`, borderTopColor:'transparent',
                          animation:'spin 0.8s linear infinite' }}/>
                        Carving your week…
                      </span>
                    ) : 'Generate plan →'}
                  </button>
                )}
              </div>
            </>
          )}

          {/* ── PREVIEW STEP ── */}
          {step === 'preview' && (
            <>
              {/* Day-by-day breakdown */}
              {DAY_NAMES.slice(0,5).map((day, i) => {
                const dayTasks = dayGroups[i]
                if (!dayTasks?.length) return null
                const totalMins = dayTasks.reduce((a,b)=>a+b.mins,0)
                return (
                  <div key={day} style={{ marginBottom:22 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:10 }}>
                      <span style={{ fontSize:11, fontWeight:700, letterSpacing:'.06em',
                        color:C.accent, textTransform:'uppercase' }}>{day}</span>
                      <div style={{ flex:1, height:1, background:C.border }}/>
                      <span style={{ fontSize:10, color:C.textMuted }}>{fmtMins(totalMins)}</span>
                    </div>
                    {dayTasks.map((t,j) => (
                      <PreviewTask key={j} task={t} goals={goals}
                        onRemove={removeTask}/>
                    ))}
                  </div>
                )
              })}

              {planned.length === 0 && (
                <div style={{ textAlign:'center', padding:'40px 20px', color:C.textMuted, fontSize:13 }}>
                  All tasks removed. Go back and try again.
                </div>
              )}

              {error && (
                <div style={{ marginBottom:16, padding:'10px 14px', background:C.errorSoft,
                  border:`1px solid ${C.error}40`, borderRadius:8, fontSize:13, color:C.error }}>
                  {error}
                </div>
              )}

              <div style={{ display:'flex', gap:10, marginTop:8, paddingTop:16,
                borderTop:`1px solid ${C.border}` }}>
                <button onClick={()=>{setStep('input');setError('')}}
                  style={{ flex:1, background:'transparent', border:`1px solid ${C.border}`,
                    borderRadius:10, color:C.textSub, fontSize:13, padding:'12px' }}>
                  ← Start over
                </button>
                <button onClick={save} disabled={planned.length===0||step==='saving'}
                  style={{ flex:2, background:C.accent, border:'none',
                    borderRadius:10, color:'#0A0E1A', fontSize:13,
                    fontWeight:800, padding:'12px', opacity:planned.length===0?0.5:1 }}>
                  {step==='saving' ? 'Saving…' : `Save ${planned.length} tasks to my week →`}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </>
  )
}
